> Pull Requests are welcome. But note that v2 of Lightbox is in Maintenance Mode and no new features
> will be added. See the [Roadmap](https://github.com/lokesh/lightbox2/blob/master/ROADMAP.md).
> 
> PRs submitted will still be reviewed and then kept open for other users to utilize.
